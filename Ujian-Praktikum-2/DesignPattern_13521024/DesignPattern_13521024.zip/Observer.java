/*
 * NIM : 13521024
 * Nama : Ahmad Nadil
 * Ujian Praktikum 2 : Design Pattern
 * 
 * Interface observer sebagai penerima notifikasi
 */


public interface Observer{
    public void update(String context);
}
